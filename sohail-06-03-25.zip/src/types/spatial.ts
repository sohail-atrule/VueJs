export interface GeographyPoint {
  latitude: number;
  longitude: number;
} 