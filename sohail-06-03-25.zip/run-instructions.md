run the dummy backend

```bash
cd dummy-backend
npm install
npm run dev
```

run the frontend

```bash
cd frontend
npm install
npm run dev
```

frontend will be available at http://localhost:8080